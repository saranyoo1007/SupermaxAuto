<?php
/**
 * SuperMax Auto Admin - Logout
 */
require_once 'auth.php';
logout();
